/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect } from 'react'
import PropTypes from 'prop-types'
import Swal from 'sweetalert2'

import authApi from "~/api/authApi"

const ChangePassword = ({ visible, setVisible, userInfo }) => {
    const handleChangePassword = () => {
        Swal.fire({
            title: 'Đổi mật khẩu',
            html: `<input type="password" id="oldpassword" class="swal2-input" placeholder="Mật khẩu cũ">
            <input type="password" id="password" class="swal2-input" placeholder="Mật khẩu mới">
            <input type="password" id="repassword" class="swal2-input" placeholder="Nhập lại mật khẩu">`,
            confirmButtonText: 'Đổi mật khẩu',
            focusConfirm: false,
            preConfirm: () => {
                const oldPassword = Swal.getPopup().querySelector('#oldpassword').value
                const password = Swal.getPopup().querySelector('#password').value
                const rePassword = Swal.getPopup().querySelector('#repassword').value
                if (!oldPassword) {
                    Swal.showValidationMessage(`Vui lòng nhập mật khẩu cũ`)
                }
                else if (!password) {
                    Swal.showValidationMessage(`Vui lòng nhập mật khẩu mới`)
                }
                else if (!rePassword) {
                    Swal.showValidationMessage(`Vui lòng nhập lại mật khẩu mới`)
                }
                else if (password !== rePassword) {
                    Swal.showValidationMessage(`Mật khẩu nhập lại không trùng khớp`)
                }
                return { oldPassword, password, rePassword }
            }
        }).then((result) => {
            if (result.isConfirmed) {
                authApi.changePassword({ id: userInfo.id, existingPassword: result.value.oldPassword, newPassword: result.value.password })
                    .then((response) => {
                        if (response.data.status === "OK") {
                            Swal.fire({
                                title: "Đổi mật khẩu",
                                text: response.data.message,
                                icon: "success",
                            })
                        }
                        else {
                            Swal.fire({
                                title: "Đổi mật khẩu",
                                text: response.data.message,
                                icon: "error",
                            })
                        }
                    })
            }
        })
        setVisible(false)
    }
    useEffect(() => {
        if (visible) {
            handleChangePassword()
        }
    }, [])
    return (
        <></>
    )
}

ChangePassword.propTypes = {}

export default ChangePassword