/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect } from 'react'
import Swal from 'sweetalert2'
import { useDispatch } from 'react-redux'
import { updateEmployee } from '~/redux/employeesSlice'
import profileApi from '~/api/profileApi'
import { getUserInfo } from '~/redux/authSlice'

const UpdateAvatar = ({ visible, setVisible, profile, setProfile }) => {

    const dispatch = useDispatch()

    const handleUpdateAvatar = async () => {
        const { value: avatar } = await Swal.fire({
            title: 'Chọn ảnh đại diện',
            input: 'file',
            inputAttributes: {
                'accept': 'image/*',
                'aria-label': 'Tải ảnh đại diện của bạn'
            }
        })

        if (avatar) {
            const reader = new FileReader()
            reader.onload = (e) => {
                Swal.fire({
                    title: 'Ảnh vừa tải',
                    imageUrl: e.target.result,
                    imageAlt: 'Ảnh đại điện'
                })
                    .then(async (result) => {
                        if (result.isConfirmed) {
                            const formData = new FormData()
                            formData.append("image", avatar)
                            const response = await profileApi.uploadAvatar(formData)
                            await dispatch(updateEmployee({
                                ...profile,
                                avatar: `${response.data.data.base64Data}`,
                                avatarLink:`${response.data.data.avatarLink}`
                            }))
                            setProfile({
                                ...profile,
                                avatar: `${response.data.data.base64Data}`,
                                avatarLink:`${response.data.data.avatarLink}`
                            })
                            dispatch(getUserInfo())
                            
                        }
                    })
            }
            reader.readAsDataURL(avatar)

        }
        setVisible(false)
    }
    useEffect(() => {
        if (visible) {
            handleUpdateAvatar()
        }
    }, [])

    return null
}

export default UpdateAvatar