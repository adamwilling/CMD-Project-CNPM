/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react"
import { Accordion, Button, Container, Image, Row, Table } from "react-bootstrap"
import { useSelector } from "react-redux"
import { useParams } from "react-router-dom"

import employeesApi from "~/api/employeesApi"
import Loading from "~/components/Loading"
import { authSelector } from "~/redux/selectors"
import ChangePassword from "./ProfileFeatures/ChangePassword"
import UpdateAvatar from "./ProfileFeatures/UpdateAvatar"

const ProfileMainPage = () => {
    const userInfo = useSelector(authSelector).userInfo

    const params = useParams()

    const [loading, setLoading] = useState(true)
    const [profile, setProfile] = useState({})
    const [visibleUpdateAvatarUI, setVisibleUpdateAvatarUI] = useState(false)
    const [visibleChangePasswordUI, setVisibleChangePasswordUI] = useState(false)

    useEffect(() => {
        document.title = `${userInfo.name} - Trang cá nhân`
        if (userInfo.id === params.id) {
            setProfile(userInfo)
        } else {
            setLoading(true)
            employeesApi.getEmployeeDetailById(params.id).then((response) => {
                setProfile(response.data.data)
                setLoading(false)
            })
        }
    }, [userInfo, params])

    return loading ? (
        <Loading />
    ) : (
        <Container fluid className="d-flex flex-md-row flex-column justify-content-around">
            <div className="col-md-3 d-flex flex-column align-items-center gap-3 mb-3">
                <Image src={profile.avatarLink} className="mb-2" width={400} height={400} />
                {userInfo.id === profile.id && (
                    <>
                        <Button className="fw-bolder" onClick={() => setVisibleUpdateAvatarUI(true)}>
                            Cập nhật ảnh đại diện
                        </Button>
                        <Button className="fw-bolder" onClick={() => setVisibleChangePasswordUI(true)}>
                            Đổi mật khẩu
                        </Button>
                    </>
                )}
            </div>
            <div className="col-md-8 d-flex flex-column justify-content-between bg-white text-break">
                <Row className="m-2">
                    <div className="col-4 fw-bolder">Trạng thái:</div>
                    <div className="col-8">
                        {profile.active ? (
                            <span className="text-success fw-bolder">Đang hoạt động</span>
                        ) : (
                            <span className="text-secondary fw-bolder">Không hoạt động</span>
                        )}
                    </div>
                </Row>
                <Row className="m-2">
                    <div className="col-4 fw-bolder">Mã số sinh viên:</div>
                    <div className="col-8">{profile.code}</div>
                </Row>
                <Row className="m-2">
                    <div className="col-4 fw-bolder">Họ và tên:</div>
                    <div className="col-8">{profile.name}</div>
                </Row>
                <Row className="m-2">
                    <div className="col-4 fw-bolder">Giới tính:</div>
                    <div className="col-8">{profile.gender === 0 ? "Nữ" : "Nam"}</div>
                </Row>
                <Row className="m-2">
                    <div className="col-4 fw-bolder">Số điện thoại:</div>
                    <div className="col-8">{profile.phoneNumber}</div>
                </Row>
                <Row className="m-2">
                    <div className="col-4 fw-bolder">Email:</div>
                    <div className="col-8">{profile.email}</div>
                </Row>
                <Row className="m-2">
                    <div className="col-4 fw-bolder">Ngày sinh:</div>
                    <div className="col-8">{profile.dateOfBirth}</div>
                </Row>
                <Accordion flush alwaysOpen>
                    <Accordion.Item eventKey="departments" className="col">
                        <Accordion.Header className="fw-bolder fs-2">DANH SÁCH PHÒNG BAN</Accordion.Header>
                        <Accordion.Body>
                            {profile.departments?.length > 0 ? (
                                <Table striped hover responsive borderless>
                                    <thead>
                                        <tr>
                                            <td>
                                                <span className="fw-bolder">TÊN PHÒNG BAN</span>
                                            </td>
                                            <td>
                                                <span className="fw-bolder">CHỨC VỤ ĐANG GIỮ</span>
                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {profile.departments?.map((department) => (
                                            <tr key={department.id}>
                                                <td>{department.name}</td>
                                                <td>{department.position?.name}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </Table>
                            ) : (
                                <div>Chưa ở trong bất cứ phòng ban nào</div>
                            )}
                        </Accordion.Body>
                    </Accordion.Item>
                    <Accordion.Item eventKey="teams" className="col">
                        <Accordion.Header className="fw-bolder fs-2">DANH SÁCH ĐỘI NHÓM</Accordion.Header>
                        <Accordion.Body>
                            {profile.teams?.length > 0 ? (
                                <Table striped hover responsive borderless>
                                    <thead>
                                        <tr>
                                            <td>
                                                <span className="fw-bolder">TÊN PHÒNG BAN</span>
                                            </td>
                                            <td>
                                                <span className="fw-bolder">CHỨC VỤ ĐANG GIỮ</span>
                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {profile.teams?.map((team) => (
                                            <tr key={team.id}>
                                                <td>{team.name}</td>
                                                <td>{team.position?.name}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </Table>
                            ) : (
                                <div>Chưa vào đội nhóm</div>
                            )}
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>
            </div>
            {visibleUpdateAvatarUI && (
                <UpdateAvatar visible={visibleUpdateAvatarUI} setVisible={setVisibleUpdateAvatarUI} profile={profile} setProfile={setProfile} />
            )}
            {visibleChangePasswordUI && <ChangePassword visible={visibleChangePasswordUI} setVisible={setVisibleChangePasswordUI} userInfo={profile} />}
        </Container>
    )
}

export default ProfileMainPage
