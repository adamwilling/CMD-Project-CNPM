/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react'
import { Button, Col, Container, Form, ListGroup } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import { TbTrash } from 'react-icons/tb'

import AppPagination from '~/components/AppPagination'
import { getNotifyList, markAllRead, markRead } from '~/redux/notifiesSlice'
import { notifiesSelector } from '~/redux/selectors'
import DeleteNotification from './features/DeleteNotification'
import { AiFillInfoCircle } from 'react-icons/ai'
import ProposalDetail from '../proposals/ProposalDetail'
import TaskDetail from '../tasks/TaskDetail'
import DeleteMultiNotification from './features/DeleteMultiNotification'
import clsx from 'clsx'

const NotificationsMainPage = () => {
    const status = useSelector(notifiesSelector).status
    const notifies = useSelector(notifiesSelector).notifies
    const pagination = useSelector(notifiesSelector).pagination

    const dispatch = useDispatch()

    const [visibleDetail, setVisibleDetail] = useState(false)
    const [visibleDeleteNotificationUI, setVisibleDeleteNotificationUI] = useState({})
    const [visibleDeleteMultiNotificationUI, setVisibleDeleteMultiNotificationUI] = useState(false)
    const [filters, setFilters] = useState({
        page: 1
    })
    const [notifyIds, setNotifyIds] = useState([])

    useEffect(() => {
        document.title = "Thông báo"
        dispatch(getNotifyList())
    }, [])

    const handlePageChange = (newPage) => {
        setFilters({
            ...filters,
            page: newPage
        })
    }

    const handleCheckNotify = (notifyId) => {
        if (notifyIds.includes(notifyId)) {
            setNotifyIds(notifyIds.filter((notifyId2) => notifyId2 !== notifyId))
        }
        else {
            setNotifyIds([...notifyIds, notifyId])
        }
    }
    const handleCheckAllNotify = () => {
        if (notifies.every((notify) => notifyIds.includes(notify.id))) {
            setNotifyIds([])
        }
        else {
            setNotifyIds(notifies.map((notify) => notify.id))
        }
    }

    return (
        <Container fluid>
            <Container fluid>
                <div className="row justify-content-xl-between justify-content-end align-items-center mb-3 gap-3">
                    <div className="col-auto fw-bolder fs-5 mb-xl-0 mb-3">
                        THÔNG BÁO
                    </div>
                    <div className="col" />
                    <div className="col-auto">
                        {/* <AppSearch
                        value={filters.name}
                        onSearch={(searchTerm) => setFilters({ q: searchTerm })}
                    /> */}
                    </div>
                    <div className="col-auto">
                        <Button
                            variant="outline-danger"
                            onClick={() => setVisibleDeleteMultiNotificationUI(true)}
                        >
                            Xóa mục đã chọn
                        </Button>
                    </div>
                    {/* <div className="col-auto">
                        <Button
                            variant="danger"
                        >
                            Xóa tất cả
                        </Button>
                    </div> */}
                    <div className="col-auto">
                        <Button
                            variant="primary"
                            onClick={() => dispatch(markAllRead())}
                        >
                            Đánh dấu tất cả đã đọc
                        </Button>
                    </div>
                </div>
            </Container>
            <Container fluid>
                {
                    notifies.length > 0 ? (
                        <ListGroup
                            className="list-group-item-action mb-4"
                            variant="flush"
                        >
                            <ListGroup.Item className="d-flex jusify-content-between align-items-center">
                                <div className="col-1">
                                    <div className="d-flex justify-content-center">
                                        <Form.Check
                                            type="checkbox"
                                            checked={notifies.every((notify) => notifyIds.includes(notify.id))}
                                            onChange={() => handleCheckAllNotify()}
                                        />
                                    </div>
                                </div>
                                <div className="col-11 d-flex flex-column p-3">
                                </div>
                            </ListGroup.Item>
                            {notifies.map((notify) => (
                                <ListGroup.Item
                                    key={notify.id}
                                    className={clsx("d-flex jusify-content-between align-items-center", { "bg-light": !notify.isRead })}
                                >
                                    <div className="col-1">
                                        <div className="d-flex justify-content-center">
                                            <Form.Check
                                                type="checkbox"
                                                checked={notifyIds.includes(notify.id)}
                                                onChange={() => handleCheckNotify(notify.id)}
                                            />
                                        </div>
                                    </div>
                                    <div className="d-flex flex-column col-10 p-3">
                                        <Col className="d-flex fw-bolder text-primary">
                                            {
                                                !notify.isRead && <div
                                                    className="col-auto rounded-circle bg-primary mt-1 me-2"
                                                    style={{ width: "10px", height: "10px" }} />
                                            }
                                            {notify.title}
                                        </Col>
                                        <Col>
                                            {notify.description}
                                        </Col>
                                        <Col className="text-black-50">
                                            {notify.createdAt}
                                        </Col>
                                    </div>
                                    <div className="col-1">
                                        <AiFillInfoCircle
                                            size={20}
                                            className="cursor-pointer me-2"
                                            onClick={() => {
                                                setVisibleDetail({
                                                    [notify.id]: true
                                                })
                                                if (!notify.isRead) {
                                                    dispatch(markRead([notify.id]))
                                                }
                                            }}
                                        />
                                        <TbTrash
                                            size={20}
                                            className="cursor-pointer"
                                            onClick={() => setVisibleDeleteNotificationUI({
                                                [notify.id]: true
                                            })}
                                        />
                                    </div>
                                    {
                                        notify.type === "proposal" ? visibleDetail[notify.id] && (
                                            <ProposalDetail
                                                visible={visibleDetail[notify.id]}
                                                setVisible={(visible) => setVisibleDetail({
                                                    [notify.id]: visible
                                                })}
                                                proposalId={notify.detailId}
                                            />
                                        ) : notify.type === "task" ? visibleDetail[notify.id] && (
                                            <TaskDetail
                                                visible={visibleDetail[notify.id]}
                                                setVisible={(visible) => setVisibleDetail({
                                                    [notify.id]: visible
                                                })}
                                                taskId={notify.detailId}
                                            />
                                        ) : null
                                    }
                                    {
                                        visibleDeleteNotificationUI[notify.id] && (
                                            <DeleteNotification
                                                visible={visibleDeleteNotificationUI[notify.id]}
                                                setVisible={(visible) => setVisibleDeleteNotificationUI({
                                                    [notify.id]: visible
                                                })}
                                                notifyId={notify.id}
                                            />
                                        )
                                    }
                                </ListGroup.Item>
                            ))
                            }
                        </ListGroup>
                    ) : (
                        <div className="text-center p-3">
                            Chưa có thông báo nào
                        </div>
                    )
                }
                <AppPagination
                    pagination={{
                        ...pagination,
                        page: filters.page
                    }}
                    onPageChange={handlePageChange}
                />

                {
                    visibleDeleteMultiNotificationUI && (
                        <DeleteMultiNotification
                            visible={visibleDeleteMultiNotificationUI}
                            setVisible={setVisibleDeleteMultiNotificationUI}
                            notifyIds={notifyIds}
                        />
                    )
                }
            </Container>
        </Container>
    )
}

export default NotificationsMainPage