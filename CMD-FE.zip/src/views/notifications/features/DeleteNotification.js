import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import Swal from 'sweetalert2'

import { deleteNotify } from '~/redux/notifiesSlice'

const DeleteNotification = ({ visible, setVisible, notifyId }) => {
    const dispatch = useDispatch()
    const handleDelete = () => {
        dispatch(deleteNotify([notifyId]))
        setVisible(false)
    }

    useEffect(() => {
        if (visible) {
            Swal.fire({
                title: "Xóa thông báo",
                html: `Bạn có chắc muốn xóa thông báo này?`,
                showCancelButton: true,
                cancelButtonText: "Hủy",
            }).then((result) => {
                if (result.isConfirmed) {
                    handleDelete()
                }
                else {
                    setVisible(false)
                }
            })
        }
    })
}

export default DeleteNotification