import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import Swal from 'sweetalert2'

import { deleteNotify } from '~/redux/notifiesSlice'

const DeleteMultiNotification = ({ visible, setVisible, notifyIds }) => {
    const dispatch = useDispatch()
    const handleDelete = () => {
        dispatch(deleteNotify([...notifyIds]))
        setVisible(false)
    }

    useEffect(() => {
        if (visible) {
            Swal.fire({
                title: "Xóa thông báo",
                html: `Bạn có chắc muốn xóa những thông báo đã chọn?`,
                showCancelButton: true,
                cancelButtonText: "Hủy",
            }).then((result) => {
                if (result.isConfirmed) {
                    handleDelete()
                }
                else {
                    setVisible(false)
                }
            })
        }
    })
}

export default DeleteMultiNotification