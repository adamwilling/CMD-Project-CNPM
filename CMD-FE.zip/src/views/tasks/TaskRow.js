import React, { useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { NavLink } from "react-router-dom"
import { Dropdown, Image, OverlayTrigger, Tooltip } from "react-bootstrap"
import { AiFillCloseCircle, AiFillInfoCircle } from "react-icons/ai"
import { BsFileEarmarkX } from "react-icons/bs"
import { BiAlarm, BiEdit } from "react-icons/bi"
import { FcOk } from "react-icons/fc"
import Swal from "sweetalert2"

import moreIcon from "~/assets/icons/more.svg"
import rate0 from "~/assets/icons/rate-0.svg"
import rate1 from "~/assets/icons/rate-1.svg"
import CancelTask from "./TasksFeatures/CancelTask"
import TaskDetail from "./TaskDetail"
import FormSubmitTask from "./TasksFeatures/SubmitTask/FormSubmitTask"
import tasksApi from "~/api/tasksApi"
import { updateTaskList } from "~/redux/tasksSlice"
import { authSelector } from "~/redux/selectors"
import TaskReminders from "./TasksFeatures/TaskReminders"

const TaskRow = ({ taskInfo }) => {
    const userInfo = useSelector(authSelector).userInfo
    const taskPermissions = useSelector(authSelector).userInfo.role.task

    const dispatch = useDispatch()

    const [visibleTaskRemindersUI, setVisibleTaskRemindersUI] = useState(false)
    const [visibleTaskDetailUI, setVisibleTaskDetailUI] = useState(false)
    const [visibleEditTaskUI, setVisibleEditTaskUI] = useState(false)
    const [visibleDeleteTaskUI, setVisibleDeleteTaskUI] = useState(false)

    const showDate = (d) => {
        const date = new Date(d)
        return (
            "" +
            (date.getDate() < 10 ? "0" : "") +
            date.getDate() +
            "/" +
            (date.getMonth() + 1 < 10 ? "0" : "") +
            (date.getMonth() + 1) +
            "/" +
            date.getFullYear()
        )
    }

    let rateElement = []
    if (taskInfo.rate > 0) {
        for (let i = 1; i <= 5; ++i) {
            if (i <= taskInfo.rate) {
                rateElement.push(<Image key={i} src={rate1} className="mx-1" />)
            } else {
                rateElement.push(<Image key={i} src={rate0} className="mx-1" />)
            }
        }
    }

    const Toast = Swal.mixin({
        toast: true,
        position: "bottom-end",
        showConfirmButton: false,
        timer: 10000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener("mouseenter", Swal.stopTimer)
            toast.addEventListener("mouseleave", Swal.resumeTimer)
        },
    })
    const handleReceiveTask = (taskId) => {
        tasksApi.receiveTask(taskId).then((response) => {
            if (response.data.status === "OK") {
                Toast.fire({
                    title: "Nhận việc",
                    text: response.data.message,
                    icon: "success",
                })
                dispatch(updateTaskList(response.data.data))
            } else {
                Toast.fire({
                    title: "Nhận việc",
                    text: response.data.message,
                    icon: "warning",
                })
            }
        })
    }
    const handleConfirmDoneTask = (taskId) => {
        tasksApi.receiveTask(taskId).then((response) => {
            if (response.data.status === "OK") {
                Toast.fire({
                    title: "Xác nhận hoàn thành",
                    text: response.data.message,
                    icon: "success",
                })
                dispatch(updateTaskList(response.data.data))
            } else {
                Toast.fire({
                    title: "Xác nhận hoàn thành",
                    text: response.data.message,
                    icon: "warning",
                })
            }
        })
    }
    const handleDoneTask = (taskId) => {
        tasksApi.receiveTask(taskId).then((response) => {
            if (response.data.status === "OK") {
                Toast.fire({
                    title: "Hoàn thành công việc",
                    text: response.data.message,
                    icon: "success",
                })
                dispatch(updateTaskList(response.data.data))
            } else {
                Toast.fire({
                    title: "Hoàn thành công việc",
                    text: response.data.message,
                    icon: "warning",
                })
            }
        })
    }
    const handleRefuseTask = async (taskId) => {
        const { value: reason } = await Swal.fire({
            title: "Từ chối nhận việc",
            input: "textarea",
            inputLabel: "Lý do từ chối",
            inputPlaceholder: "Nhập lý do từ chối...",
            inputAttributes: {
                "aria-label": "Nhập lý do từ chối",
            },
            showCancelButton: true,
        })

        if (reason) {
            return tasksApi
                .refuseTask({
                    id: taskId,
                    reason: reason,
                })
                .then((response) => {
                    if (response.data.status === "OK") {
                        Toast.fire({
                            title: "Từ chối nhận việc",
                            text: response.data.message,
                            icon: "success",
                        })
                        dispatch(updateTaskList(response.data.data))
                    } else {
                        Toast.fire({
                            title: "Từ chối nhận việc",
                            text: response.data.message,
                            icon: "warning",
                        })
                    }
                })
        }
    }
    const handleRefuseDoneTask = async (taskId) => {
        const { value: reason } = await Swal.fire({
            title: "Từ chối xác nhận hoàn thành",
            input: "textarea",
            inputLabel: "Lý do từ chối xác nhận",
            inputPlaceholder: "Nhập lý do từ chối xác nhận hoàn thành công việc...",
            inputAttributes: {
                "aria-label": "Nhập lý do từ chối xác nhận hoàn thành công việc",
            },
            showCancelButton: true,
        })

        if (reason) {
            return tasksApi
                .refuseTask({
                    id: taskId,
                    reason: reason,
                })
                .then((response) => {
                    if (response.data.status === "OK") {
                        Toast.fire({
                            title: "Từ chối xác nhận hoàn thành",
                            text: response.data.message,
                            icon: "success",
                        })
                        dispatch(updateTaskList(response.data.data))
                    } else {
                        Toast.fire({
                            title: "Từ chối xác nhận hoàn thành",
                            text: response.data.message,
                            icon: "warning",
                        })
                    }
                })
        }
    }

    let dropdownItemElement = null
    if (userInfo.id === taskInfo.receiver?.id) {
        if (taskInfo.status?.index === 1 || taskInfo.status?.index === 7) {
            dropdownItemElement = (
                <>
                    <Dropdown.Item className="text-success" onClick={() => handleReceiveTask(taskInfo.id)}>
                        <FcOk /> Nhận việc
                    </Dropdown.Item>
                    <Dropdown.Item className="text-danger" onClick={() => handleRefuseTask(taskInfo.id)}>
                        <AiFillCloseCircle /> Từ chối
                    </Dropdown.Item>

                    <Dropdown.Divider />
                </>
            )
        } else if (taskInfo.status?.index === 2) {
            dropdownItemElement = (
                <>
                    <Dropdown.Item className="text-success" onClick={() => handleDoneTask(taskInfo.id)}>
                        <FcOk /> Hoàn thành
                    </Dropdown.Item>
                    <Dropdown.Divider />
                </>
            )
        }
    } else if (userInfo.id === taskInfo.creator?.id) {
        if (taskInfo.status?.index === 3) {
            dropdownItemElement = (
                <>
                    <Dropdown.Item className="text-success" onClick={() => handleConfirmDoneTask(taskInfo.id)}>
                        <FcOk /> Xác nhận hoàn thành
                    </Dropdown.Item>
                    <Dropdown.Item className="text-danger" onClick={() => handleRefuseDoneTask(taskInfo.id)}>
                        <AiFillCloseCircle /> Từ chối
                    </Dropdown.Item>

                    <Dropdown.Divider />
                </>
            )
        }
    }

    return (
        <>
            <div className="item task list-group-item">
                <div className="item-label" />
                <div className="ms-lg-5" />
                <div className="task-title">
                    <div className="d-lg-none fw-bold col text-break">Tên công việc:</div>
                    <div className="col text-break">{taskInfo.title}</div>
                </div>
                <div className="task-creator">
                    <div className="d-lg-none fw-bold col text-break">Người giao:</div>
                    <div className="col">
                        <NavLink to={`/profile/${taskInfo.creator.id}`}>
                            <OverlayTrigger placement="top-start" overlay={<Tooltip>{taskInfo.creator.name}</Tooltip>}>
                                <Image
                                    className="rounded-circle float-end cursor-pointer"
                                    width={35}
                                    height={35}
                                    src={"data:image/png;base64," + taskInfo.creator.avatar}
                                />
                            </OverlayTrigger>
                        </NavLink>
                    </div>
                </div>
                <div className="task-arrow" />
                <div className="task-receiver">
                    <div className="d-lg-none fw-bold col text-break">Người nhận:</div>
                    <div className="col text-break">
                        <NavLink to={`/profile/${taskInfo.receiver.id}`}>
                            <OverlayTrigger placement="top-start" overlay={<Tooltip>{taskInfo.receiver.name}</Tooltip>}>
                                <Image
                                    className="rounded-circle float-start cursor-pointer"
                                    width={35}
                                    height={35}
                                    src={"data:image/png;base64," + taskInfo.receiver.avatar}
                                />
                            </OverlayTrigger>
                        </NavLink>
                    </div>
                </div>
                <div className="task-timeline">
                    <div className="d-lg-none fw-bold col text-break">Thời gian:</div>
                    <div className="col text-break">{showDate(taskInfo.startDate) + " - " + showDate(taskInfo.finishDate)}</div>
                </div>
                <div className="task-status">
                    <div className="d-lg-none fw-bold col text-break">Tình trạng:</div>
                    <div className="col text-break fw-bolder">
                        {(taskInfo.status.index === 1 && <span className="text-primary">Mới</span>) ||
                            (taskInfo.status.index === 2 && <span className="text-info">Đang làm</span>) ||
                            (taskInfo.status.index === 3 && <span className="text-warning">Chờ xác nhận</span>) ||
                            (taskInfo.status.index === 4 && <span className="text-success">Hoàn thành</span>) ||
                            (taskInfo.status.index === 5 && <span className="text-secondary">Đã hủy</span>) ||
                            (taskInfo.status.index === 6 && <span className="text-danger">Quá hạn</span>) ||
                            (taskInfo.status.index === 7 && <span className="text-primary">Mở lại</span>)}
                    </div>
                </div>
                <div className="task-rate">
                    <div className="d-lg-none fw-bold col text-break">Đánh giá:</div>
                    <div className="col d-flex justify-content-center">{rateElement}</div>
                </div>
                <Dropdown className="task-more more">
                    {(((taskPermissions.update_all || (taskPermissions.update && userInfo.id === taskInfo.creator?.id)) &&
                        [1, 2, 6].includes(taskInfo.status?.index)) ||
                        ((taskPermissions.delete_all || (taskPermissions.delete && userInfo.id === taskInfo.creator?.id)) && taskInfo.status?.index < 4) ||
                        (userInfo.id === taskInfo.receiver?.id && (taskInfo.status?.index === 1 || taskInfo.status?.index === 7)) ||
                        (userInfo.id === taskInfo.receiver?.id && taskInfo.status?.index === 2) ||
                        (userInfo.id === taskInfo.creator?.id && taskInfo.status?.index === 3) ||
                        userInfo.id === taskInfo.creator?.id) && (
                        <>
                            <Dropdown.Toggle variant="none">
                                <Image src={moreIcon} />
                            </Dropdown.Toggle>
                            <Dropdown.Menu className="animate__animated animate__zoomIn animate__faster">
                                {dropdownItemElement}
                                {
                                    userInfo.id === taskInfo.creator?.id && (
                                        <Dropdown.Item onClick={() => setVisibleTaskRemindersUI(true)}>
                                            <BiAlarm /> Thiết lập nhắc việc
                                        </Dropdown.Item>
                                    )
                                }
                                {(taskPermissions.update_all || (taskPermissions.update && userInfo.id === taskInfo.creator?.id)) &&
                                    [1, 2, 6].includes(taskInfo.status?.index) && (
                                        <Dropdown.Item onClick={() => setVisibleEditTaskUI(true)}>
                                            <BiEdit /> Chỉnh sửa
                                        </Dropdown.Item>
                                    )}
                                {(taskPermissions.delete_all || (taskPermissions.delete && userInfo.id === taskInfo.creator?.id)) &&
                                    taskInfo.status?.index < 4 && (
                                        <Dropdown.Item onClick={() => setVisibleDeleteTaskUI(true)}>
                                            <BsFileEarmarkX /> Hủy
                                        </Dropdown.Item>
                                    )}
                            </Dropdown.Menu>
                        </>
                    )}
                    <div className="view-detail" onClick={() => setVisibleTaskDetailUI(true)}>
                        <AiFillInfoCircle size={20} />
                    </div>
                </Dropdown>
                <div className="view-detail-custom" onClick={() => setVisibleTaskDetailUI(true)}>
                    <AiFillInfoCircle size={20} />
                </div>
            </div>
            {visibleTaskRemindersUI && <TaskReminders visible={visibleTaskRemindersUI} setVisible={setVisibleTaskRemindersUI} task={taskInfo} />}
            {visibleTaskDetailUI && <TaskDetail visible={visibleTaskDetailUI} setVisible={setVisibleTaskDetailUI} task={taskInfo} />}
            {visibleEditTaskUI && <FormSubmitTask visible={visibleEditTaskUI} setVisible={setVisibleEditTaskUI} task={taskInfo} />}
            {visibleDeleteTaskUI && <CancelTask visible={visibleDeleteTaskUI} setVisible={setVisibleDeleteTaskUI} taskInfo={taskInfo} />}
        </>
    )
}

export default TaskRow
