import React, { useEffect } from 'react'
import PropTypes from 'prop-types'
import { Button, Modal } from 'react-bootstrap'
import { useDispatch } from 'react-redux'

import { updateTask } from '~/redux/tasksSlice'
import Swal from 'sweetalert2'

const propTypes = {
    visible: PropTypes.bool.isRequired,
    setVisible: PropTypes.func.isRequired,
    taskInfo: PropTypes.object.isRequired
}

const CancelTask = ({ visible, setVisible, taskInfo }) => {
    const dispatch = useDispatch()
    const handleCancel = () => {
        dispatch(updateTask({
            ...taskInfo,
            receiverId: taskInfo.receiver.id,
            statusId: 5
        }))
        setVisible(false)
    }

    useEffect(() => {
        if (visible) {
            Swal.fire({
                title: "Hủy công việc",
                html: `Bạn có chắc muốn hủy công việc <strong>${taskInfo.title}</strong>?`,
                showCancelButton: true,
                cancelButtonText: "Hủy",
            }).then((result) => {
                if (result.isConfirmed) {
                    handleCancel()
                }
                else {
                    setVisible(false)
                }
            })
        }
    })
}

CancelTask.propTypes = propTypes

export default CancelTask