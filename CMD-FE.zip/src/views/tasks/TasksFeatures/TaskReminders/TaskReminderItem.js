/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Button, Form } from "react-bootstrap"
import { Formik } from "formik"
import * as Yup from "yup"
import clsx from "clsx"

import { addTaskReminder, deleteTaskReminder, resetStatus, updateTaskReminder } from "~/redux/tasksSlice"
import { tasksSelector } from "~/redux/selectors"
import { BiTrash } from "react-icons/bi"

const TaskReminderItem = ({ index, setVisible, task, reminder }) => {
    const status = useSelector(tasksSelector).status

    const dispatch = useDispatch()

    useEffect(() => {
        if (status === "success") {
            if (!reminder?.id) {
                setVisible((preState) => preState.filter((state, indexState) => index === indexState))
            }
            dispatch(resetStatus())
        }
    }, [status])

    /* Xử lý Form với Formik */
    let initialValues = {
        time: new Date().toISOString().split("T")[0] + " " + new Date().toLocaleTimeString(),
    }
    if (reminder?.id) {
        initialValues = reminder
    }
    const validationSchema = Yup.object({
        time: Yup.date()
            .required("Vui lòng chọn thời gian nhắc việc")
            .test(
                "timeable",
                "Thời gian nhắc việc phải từ thời gian hiện tại đến hạn chót công việc",
                (value) => new Date(value).getTime() - new Date().getTime() > 0 && new Date(task.finishDate).getTime() - new Date(value).getTime() > 0
            ),
    })
    const handleSubmit = async (values, actions) => {
        actions.setSubmitting(true)
        if (reminder?.id) {
            dispatch(
                updateTaskReminder({
                    ...values,
                    time: values.time.replace("T", " "),
                })
            )
        } else {
            dispatch(
                addTaskReminder({
                    ...values,
                    taskId: task.id,
                    time: values.time.replace("T", " "),
                })
            )
        }
        actions.setSubmitting(false)
    }
    const handleDelete = () => {
        if (reminder?.id) {
            dispatch(deleteTaskReminder(reminder?.id))
        } else {
            setVisible((preState) => preState.filter((state, indexState) => index === indexState))
        }
    }

    return (
        <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
            {({ values, touched, errors, handleChange, handleBlur, handleSubmit, isValid, dirty }) => (
                <Form onSubmit={handleSubmit} className="p-3">
                    <div className="d-flex justify-content-center">
                        <Form.Label className="col">
                            Thời gian nhắc việc<span style={{ color: "red" }}>*</span>:
                        </Form.Label>
                        {reminder?.id && <div className="col-auto text-end">Còn lại {reminder?.timeRemaining}</div>}
                    </div>
                    <Form.Control
                        type="datetime-local"
                        name="time"
                        className={clsx({
                            "is-invalid": touched.time && errors.time,
                        })}
                        value={values.time}
                        onChange={handleChange}
                        onBlur={handleBlur}
                    />
                    {touched.time && errors.time && <div className="invalid-feedback">{errors.time}</div>}
                    <div className="row justify-content-end">
                        <Button variant="none" className="col-auto me-3" onClick={handleDelete}>
                            <BiTrash />
                        </Button>
                    </div>
                    <Button type="submit" disabled={!(dirty && isValid) || status === "sending"} className="d-flex align-items-center">
                        <span className="fw-bolder">Lưu</span>
                        {/* {status === "sending" && <Spinner as="span" animation="border" size="sm" className="ms-2" />} */}
                    </Button>
                </Form>
            )}
        </Formik>
    )
}

export default TaskReminderItem
