/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Button, ListGroup, Modal } from "react-bootstrap"

import { getTaskReminders, resetStatus } from "~/redux/tasksSlice"
import { authSelector, tasksSelector } from "~/redux/selectors"
import TaskReminderItem from "./TaskReminderItem"
import Loading from "~/components/Loading"

const TaskReminders = ({ visible, setVisible, task = null }) => {
    const userInfo = useSelector(authSelector).userInfo
    const taskPermissions = useSelector(authSelector).userInfo.role.task
    const status = useSelector(tasksSelector).status
    const reminders = useSelector(tasksSelector).reminders.map((reminder) => ({ ...reminder, time: reminder.time.replace(" ", "T") }))

    const [visibleAddReminderUI, setVisibleAddReminderUI] = useState([])

    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(getTaskReminders(task.id))
    }, [])

    const handleShowFormAddReminder = () => {
        setVisibleAddReminderUI([...visibleAddReminderUI, <TaskReminderItem key={visibleAddReminderUI.length + 1} index={visibleAddReminderUI.length + 1} setVisible={setVisibleAddReminderUI} task={task} />])
    }

    return (
        <Modal className="modal-fullheight" size="lg" backdrop="static" scrollable show={visible} onHide={() => setVisible(false)}>
            <Modal.Header closeButton>
                <Modal.Title>Nhắc việc - {task.title}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className="text-danger fw-bold mb-3">*Thông báo nhắc việc sẽ được tự động gửi đến email của người nhận khi đến thời gian đã thiếp lập</div>
                {status === "loadingReminders" ? (
                    <Loading />
                ) : (
                    reminders.map((reminder) => (
                        <div key={reminder.id} className="bg-light text-body mb-4">
                            <TaskReminderItem reminder={reminder} task={task} />
                        </div>
                    ))
                )}
                {visibleAddReminderUI}
                {taskPermissions.create && (
                    <div className="mb-3 mt-3">
                        <Button variant="outline-primary" className="d-table m-auto" onClick={handleShowFormAddReminder}>
                            Thêm nhắc nhở
                        </Button>
                    </div>
                )}
            </Modal.Body>
        </Modal>
    )
}

export default TaskReminders
