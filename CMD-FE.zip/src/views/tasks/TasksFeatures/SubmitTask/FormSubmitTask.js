/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { Button, Form, Modal, Row, Spinner } from "react-bootstrap"
import { Formik } from "formik"
import * as Yup from "yup"
import clsx from "clsx"

import { addTask, resetStatus, updateTask } from "~/redux/tasksSlice"
import SelectReiver from "./SelectReceiver"
import { authSelector, tasksSelector } from "~/redux/selectors"

const FormSubmitTask = ({ visible, setVisible, task = null }) => {
    const userInfo = useSelector(authSelector).userInfo
    const status = useSelector(tasksSelector).status

    const dispatch = useDispatch()

    useEffect(() => {
        if (status === "success") {
            setVisible(false)
            dispatch(resetStatus())
        }
    }, [status])

    const prioritySelectElement = (priority, handlePriorityChange) => {
        const colors = ["#75FFD6", "#3CEBC1", "#0DD2DE", "#4BA6FB"]
        const names = ["Thấp", "Bình thường", "Ưu tiên", "Rất ưu tiên"]
        let els = []
        for (let i = 1; i <= priority; i++) {
            els.push(
                <div key={i} className="col-sm-3 d-flex flex-column w-25">
                    <Button
                        variant="outline-primary"
                        style={{ backgroundColor: i <= priority ? colors[i - 1] : null, borderColor: i <= priority ? colors[i] : null }}
                        onClick={() => handlePriorityChange(i)}
                    />
                    <span className="text-center">{names[i - 1]}</span>
                </div>
            )
        }
        if (priority < colors.length) {
            for (let i = priority + 1; i <= colors.length; i++) {
                els.push(
                    <div key={i} className="col-sm-3 d-flex flex-column w-25">
                        <Button
                            variant="outline-primary"
                            style={{ backgroundColor: i <= priority ? colors[i - 1] : null }}
                            onClick={() => handlePriorityChange(i)}
                        />
                        <span className="text-center">{names[i - 1]}</span>
                    </div>
                )
            }
        }
        return els.map((item) => item)
    }

    /* Xử lý Form với Formik */
    let initialValues = {
        title: "",
        receiver: {
            id: -1,
            name: "Chọn nhân viên",
        },
        priority: 1,
        description: "",
        startDate: "",
        finishDate: "",
    }
    if (task?.id) {
        initialValues = task
    }
    const validationSchema = Yup.object({
        title: Yup.string().required("Vui lòng nhập tên công việc.").max(45, "Tên công việc phải ít hơn 45 ký tự."),
        receiver: Yup.object({
            id: Yup.number().required("Vui lòng chọn người được giao"),
            name: Yup.string().required(),
        }),
        priority: Yup.number().required("Vui lòng chọn mức độ ưu tiên"),
        description: Yup.string().required("Vui lòng nhập mô tả công việc"),
        startDate: Yup.date().required("Vui lòng nhập ngày bắt đầu."),
        finishDate: Yup.date()
            .required("Vui lòng nhập ngày kết thúc.")
            .test("timeWork", "Thời hạn công việc tối thiểu 1 ngày", function (finishDate, context) {
                return new Date(context.parent.startDate).getTime() < new Date(finishDate).getTime()
            }),
    })
    const handleSubmit = async (values, actions) => {
        actions.setSubmitting(true)
        if (task?.id) {
            dispatch(
                updateTask({
                    ...values,
                    receiverId: values.receiver.id,
                })
            )
        } else {
            dispatch(
                addTask({
                    ...values,
                    receiverId: values.receiver.id,
                })
            )
        }
        actions.setSubmitting(false)
    }

    return (
        <Modal className="modal-fullheight" size="lg" backdrop="static" scrollable show={visible} onHide={() => setVisible(false)}>
            <Modal.Header closeButton>
                <Modal.Title>{task?.id ? "Chỉnh sửa công việc" : "Thêm công việc"}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
                    {({ values, touched, errors, handleChange, handleBlur, handleSubmit, setFieldValue, isValid, dirty }) => (
                        <Form onSubmit={handleSubmit}>
                            <div className="mb-4">
                                <Form.Label>
                                    Tên công việc<span style={{ color: "red" }}>*</span>:
                                </Form.Label>
                                <Form.Control
                                    type="text"
                                    name="title"
                                    placeholder="Nhập tên công việc"
                                    className={clsx({
                                        "is-invalid": touched.title && errors.title,
                                    })}
                                    value={values.title}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                />
                                {touched.title && errors.title && <div className="invalid-feedback">{errors.title}</div>}
                            </div>
                            <div className="mb-4">
                                <Form.Label>
                                    Người nhận<span style={{ color: "red" }}>*</span>:
                                </Form.Label>
                                <SelectReiver
                                    placeholder="Chọn người nhận"
                                    current={values.receiver}
                                    onChange={(receiver) => {
                                        setFieldValue("receiver", receiver)
                                    }}
                                />
                                {touched.receiver?.id && errors.receiver?.id && <div className="invalid-feedback">{errors.receiver?.id}</div>}
                            </div>
                            <div className="mb-4">
                                <Form.Label>
                                    Mức độ ưu tiên<span style={{ color: "red" }}>*</span>:
                                </Form.Label>
                                <Row>
                                    {prioritySelectElement(values.priority, (priority) => {
                                        setFieldValue("priority", priority)
                                    })}
                                </Row>
                            </div>
                            <div className="mb-4">
                                <Form.Label>
                                    Mô tả<span style={{ color: "red" }}>*</span>:
                                </Form.Label>
                                <Form.Control
                                    as="textarea"
                                    name="description"
                                    placeholder="Nhập mô tả công việc"
                                    rows={10}
                                    className={clsx({
                                        "is-invalid": touched.description && errors.description,
                                    })}
                                    value={values.description}
                                    onChange={handleChange}
                                    onBlur={handleBlur}
                                />
                                {touched.description && errors.description && <div className="invalid-feedback">{errors.description}</div>}
                            </div>
                            <Row className="mb-4 justify-content-betwween">
                                <div className="col-12 mb-4 col-lg-6 mb-lg-0">
                                    <Form.Label>
                                        Thời gian bắt đầu<span style={{ color: "red" }}>*</span>:
                                    </Form.Label>
                                    <Form.Control
                                        type="date"
                                        min={new Date()}
                                        max={values.finishDate}
                                        name="startDate"
                                        className={clsx({
                                            "is-invalid": touched.startDate && errors.startDate,
                                        })}
                                        value={values.startDate}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    />
                                    {touched.startDate && errors.startDate && <div className="invalid-feedback">{errors.startDate}</div>}
                                </div>
                                <div className="col-12 col-lg-6">
                                    <Form.Label>
                                        Hạn chót<span style={{ color: "red" }}>*</span>:
                                    </Form.Label>
                                    <Form.Control
                                        type="date"
                                        min={values.startDate}
                                        name="finishDate"
                                        className={clsx({
                                            "is-invalid": touched.finishDate && errors.finishDate,
                                        })}
                                        value={values.finishDate}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                    />
                                    {touched.finishDate && errors.finishDate && <div className="invalid-feedback">{errors.finishDate}</div>}
                                </div>
                            </Row>
                            <div className="mb-6" />
                            <Modal.Footer>
                                <Button type="submit" disabled={!(dirty && isValid) || status === "sending"} className="d-flex align-items-center">
                                    <span className="fw-bolder">{task?.id ? "Cập nhật" : "Tạo công việc"}</span>
                                    {status === "sending" && (
                                        <Spinner
                                            as="span"
                                            animation="border"
                                            size="sm"
                                            className="ms-2"
                                        />
                                    )}
                                </Button>
                            </Modal.Footer>
                        </Form>
                    )}
                </Formik>
            </Modal.Body>
        </Modal>
    )
}

export default FormSubmitTask
