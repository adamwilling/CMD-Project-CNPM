/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react"
import PropTypes from "prop-types"
import { Accordion, Button, Col, Image, Modal, Row } from "react-bootstrap"
import Swal from "sweetalert2"

import rate0 from "~/assets/icons/rate-0.svg"
import rate1 from "~/assets/icons/rate-1.svg"
import tasksApi from "~/api/tasksApi"
import TaskHistory from "./TaskHistory"
import { useDispatch, useSelector } from "react-redux"
import { updateTaskList } from "~/redux/tasksSlice"
import clsx from "clsx"
import { authSelector } from "~/redux/selectors"
import TaskDiscussion from "./TaskDiscussion"
import { useNavigate } from "react-router-dom"

const propTypes = {
    visible: PropTypes.bool.isRequired,
    setVisible: PropTypes.func.isRequired,
    task: PropTypes.object,
    taskId: PropTypes.number,
}

const TaskDetail = ({ visible, setVisible, task, taskId }) => {
    const userInfo = useSelector(authSelector).userInfo

    const dispatch = useDispatch()
    const navigate = useNavigate()

    const [taskInfo, setTaskInfo] = useState({})

    useEffect(() => {
        if (taskId) {
            tasksApi.getTaskDetailById(taskId).then((response) => {
                setTaskInfo(response.data.data)
            })
        }
        if (task) {
            setTaskInfo(task)
        }
    }, [])

    const showDate = (d) => {
        const date = new Date(d)
        return (
            "" +
            (date.getDate() < 10 ? "0" : "") +
            date.getDate() +
            "/" +
            (date.getMonth() + 1 < 10 ? "0" : "") +
            (date.getMonth() + 1) +
            "/" +
            date.getFullYear()
        )
    }

    const handleRate = (rate) => {
        tasksApi
            .updateTask({
                ...taskInfo,
                receiverId: taskInfo.receiver.id,
                statusId: taskInfo.status.id,
                rate,
            })
            .then((response) => {
                if (response.data.status === "OK") {
                    Toast.fire({
                        title: "Đánh giá chất lượng công việc",
                        text: response.data.message,
                        icon: "success",
                    })
                    setTaskInfo(response.data.data)
                    dispatch(updateTaskList(response.data.data))
                } else {
                    Toast.fire({
                        title: "Đánh giá chất lượng công việc",
                        text: response.data.message,
                        icon: "warning",
                    })
                }
            })
    }

    let rateElement = []
    if (taskInfo.rate > 0) {
        for (let i = 1; i <= 5; ++i) {
            if (i <= taskInfo.rate) {
                rateElement.push(
                    <Image
                        key={i}
                        className={clsx("mx-1 p-1", { "cursor-pointer": userInfo.id === taskInfo.creator?.id })}
                        width={25}
                        src={rate1}
                        onClick={() => {
                            if (userInfo.id === taskInfo.creator?.id) {
                                handleRate(i)
                            }
                        }}
                    />
                )
            } else {
                rateElement.push(
                    <Image
                        key={i}
                        className={clsx("mx-1 p-1", { "cursor-pointer": userInfo.id === taskInfo.creator?.id })}
                        width={25}
                        src={rate0}
                        onClick={() => {
                            if (userInfo.id === taskInfo.creator?.id) {
                                handleRate(i)
                            }
                        }}
                    />
                )
            }
        }
    }

    const Toast = Swal.mixin({
        toast: true,
        position: "bottom-end",
        showConfirmButton: false,
        timer: 10000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener("mouseenter", Swal.stopTimer)
            toast.addEventListener("mouseleave", Swal.resumeTimer)
        },
    })
    const handleReceiveTask = (taskId) => {
        tasksApi.receiveTask(taskId).then((response) => {
            if (response.data.status === "OK") {
                Toast.fire({
                    title: "Nhận việc",
                    text: response.data.message,
                    icon: "success",
                })
                setTaskInfo(response.data.data)
                dispatch(updateTaskList(response.data.data))
            } else {
                Toast.fire({
                    title: "Nhận việc",
                    text: response.data.message,
                    icon: "warning",
                })
            }
        })
    }
    const handleConfirmDoneTask = (taskId) => {
        tasksApi.receiveTask(taskId).then((response) => {
            if (response.data.status === "OK") {
                Toast.fire({
                    title: "Xác nhận hoàn thành",
                    text: response.data.message,
                    icon: "success",
                })
                setTaskInfo(response.data.data)
                dispatch(updateTaskList(response.data.data))
            } else {
                Toast.fire({
                    title: "Xác nhận hoàn thành",
                    text: response.data.message,
                    icon: "warning",
                })
            }
        })
    }
    const handleDoneTask = (taskId) => {
        tasksApi.receiveTask(taskId).then((response) => {
            if (response.data.status === "OK") {
                Toast.fire({
                    title: "Hoàn thành công việc",
                    text: response.data.message,
                    icon: "success",
                })
                setTaskInfo(response.data.data)
                dispatch(updateTaskList(response.data.data))
            } else {
                Toast.fire({
                    title: "Hoàn thành công việc",
                    text: response.data.message,
                    icon: "warning",
                })
            }
        })
    }
    const handleRefuseTask = async (taskId) => {
        setVisible(false)
        const { value: reason } = await Swal.fire({
            title: "Từ chối nhận việc",
            input: "textarea",
            inputLabel: "Lý do từ chối",
            inputPlaceholder: "Nhập lý do từ chối...",
            inputAttributes: {
                "aria-label": "Nhập lý do từ chối",
            },
            showCancelButton: true,
        })

        if (reason) {
            return tasksApi
                .refuseTask({
                    id: taskId,
                    reason: reason,
                })
                .then((response) => {
                    if (response.data.status === "OK") {
                        Toast.fire({
                            title: "Từ chối nhận việc",
                            text: response.data.message,
                            icon: "success",
                        })
                        setTaskInfo(response.data.data)
                        dispatch(updateTaskList(response.data.data))
                    } else {
                        Toast.fire({
                            title: "Từ chối nhận việc",
                            text: response.data.message,
                            icon: "warning",
                        })
                    }
                })
        }
    }
    const handleRefuseDoneTask = async (taskId) => {
        setVisible(false)
        const { value: reason } = await Swal.fire({
            title: "Từ chối xác nhận hoàn thành",
            input: "textarea",
            inputLabel: "Lý do từ chối xác nhận",
            inputPlaceholder: "Nhập lý do từ chối xác nhận hoàn thành công việc...",
            inputAttributes: {
                "aria-label": "Nhập lý do từ chối xác nhận hoàn thành công việc",
            },
            showCancelButton: true,
        })

        if (reason) {
            return tasksApi
                .refuseTask({
                    id: taskId,
                    reason: reason,
                })
                .then((response) => {
                    if (response.data.status === "OK") {
                        Toast.fire({
                            title: "Từ chối xác nhận hoàn thành",
                            text: response.data.message,
                            icon: "success",
                        })
                        setTaskInfo(response.data.data)
                        dispatch(updateTaskList(response.data.data))
                    } else {
                        Toast.fire({
                            title: "Từ chối xác nhận hoàn thành",
                            text: response.data.message,
                            icon: "warning",
                        })
                    }
                })
        }
    }

    let buttonElement = null
    if (userInfo.id === taskInfo.receiver?.id) {
        if (taskInfo.status?.id === 1 || taskInfo.status?.index === 7) {
            buttonElement = (
                <>
                    <div className="mb-6" />
                    <Modal.Footer>
                        <Button variant="success" className="col-4 fw-bolder mx-2" onClick={() => handleReceiveTask(taskInfo.id)}>
                            Nhận việc
                        </Button>
                        <Button variant="danger" className="col-4 fw-bolder mx-2" onClick={() => handleRefuseTask(taskInfo.id)}>
                            Từ chối
                        </Button>
                    </Modal.Footer>
                </>
            )
        } else if (taskInfo.status?.id === 2) {
            buttonElement = (
                <>
                    <div className="mb-6" />
                    <Modal.Footer>
                        <Button variant="primary" className="col-4 fw-bolder mx-2" onClick={() => handleDoneTask(taskInfo.id)}>
                            Hoàn thành
                        </Button>
                    </Modal.Footer>
                </>
            )
        }
    } else if (userInfo.id === taskInfo.creator?.id) {
        if (taskInfo.status?.id === 3) {
            buttonElement = (
                <>
                    <div className="mb-6" />
                    <Modal.Footer>
                        <Button variant="success" className="col-4 fw-bolder mx-2" onClick={() => handleConfirmDoneTask(taskInfo.id)}>
                            Xác nhận hoàn thành
                        </Button>
                        <Button variant="danger" className="col-4 fw-bolder mx-2" onClick={() => handleRefuseDoneTask(taskInfo.id)}>
                            Từ chối
                        </Button>
                    </Modal.Footer>
                </>
            )
        }
    }

    return (
        <Modal className="modal-fullheight" size="lg" scrollable show={visible} onHide={() => setVisible(false)}>
            <Modal.Header closeButton>
                <Modal.Title>Chi tiết công việc</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className="d-flex flex-column justify-content-between">
                    <Row className="m-2">
                        <div className="col-4 fw-bolder">Tên công việc:</div>
                        <div className="col-8">{taskInfo.title}</div>
                    </Row>
                    <Row className="m-2">
                        <div className="col-4 fw-bolder">Thời hạn:</div>
                        <div className="col-8">{showDate(taskInfo.startDate) + " - " + showDate(taskInfo.finishDate)}</div>
                    </Row>
                    <Row className="m-2">
                        <div className="col-4 fw-bolder">Mức độ ưu tiên:</div>
                        <div className="col-8">
                            {taskInfo.priority === 1 ? "Thấp" : taskInfo.priority === 2 ? "Trung bình" : taskInfo.priority === 3 ? "Cao" : "Rất cao"}
                        </div>
                    </Row>
                    <Row className="m-2">
                        <div className="col-4 fw-bolder">Người giao:</div>
                        <div className="col-8">
                            <div className="d-flex cursor-pointer" onClick={() => navigate(`/profile/${taskInfo.creator?.id}`)}>
                                <Image
                                    src={"data:image/png;base64," + taskInfo.creator?.avatar}
                                    style={{ width: "40px", height: "40px" }}
                                    className="rounded-circle col-auto me-2"
                                />
                                <Row className="flex-column">
                                    <Col className="fw-bolder text-primary">{taskInfo.creator?.name}</Col>
                                    <Col>{taskInfo.creator?.code}</Col>
                                </Row>
                            </div>
                        </div>
                    </Row>
                    <Row className="m-2">
                        <div className="col-4 fw-bolder">Người nhận:</div>
                        <div className="col-8">
                            <div className="d-flex cursor-pointer" onClick={() => navigate(`/profile/${taskInfo.receiver?.id}`)}>
                                <Image
                                    src={"data:image/png;base64," + taskInfo.receiver?.avatar}
                                    style={{ width: "40px", height: "40px" }}
                                    className="rounded-circle col-auto me-2"
                                />
                                <Row className="flex-column">
                                    <Col className="fw-bolder text-primary">{taskInfo.receiver?.name}</Col>
                                    <Col>{taskInfo.receiver?.code}</Col>
                                </Row>
                                <Row className="flex-column">
                                    <Col className="fw-bolder text-primary">{taskInfo.receiver?.name}</Col>
                                    <Col>{taskInfo.receiver?.code}</Col>
                                </Row>
                            </div>
                        </div>
                    </Row>
                    <Row className="m-2">
                        <div className="col-4 fw-bolder">Phòng ban:</div>
                        <div className="col-8">{taskInfo?.department && taskInfo?.department[0].name}</div>
                    </Row>
                    <Row className="m-2">
                        <span className="fw-bolder">Mô tả:</span>
                        <span>{taskInfo.description}</span>
                    </Row>
                    <Row className="m-2">
                        <div className="col-4 fw-bolder">Trạng thái:</div>
                        <div className="col-8">
                            {taskInfo.status?.name === "Hoàn thành" ? (
                                <>
                                    {taskInfo.status?.name} ({showDate(taskInfo.modifyDate)})
                                </>
                            ) : (
                                <strong>{taskInfo.status?.name}</strong>
                            )}
                        </div>
                    </Row>
                    <Row className="m-2">
                        <div className="col-4 fw-bolder">Đánh giá:</div>
                        <div className="col-8">{rateElement}</div>
                    </Row>
                    <Accordion flush alwaysOpen>
                        <Accordion.Item eventKey="0">
                            <Accordion.Header className="fw-bold">LỊCH SỬ HOẠT ĐỘNG</Accordion.Header>
                            <Accordion.Body>
                                <TaskHistory taskInfo={taskInfo} />
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="1">
                            <Accordion.Header className="fw-bold">THẢO LUẬN</Accordion.Header>
                            <Accordion.Body>
                                <TaskDiscussion taskId={task?.id || taskInfo?.id} />
                            </Accordion.Body>
                        </Accordion.Item>
                    </Accordion>
                </div>
            </Modal.Body>
            {buttonElement}
        </Modal>
    )
}

TaskDetail.propTypes = propTypes

export default TaskDetail
