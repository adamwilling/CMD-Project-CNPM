/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react"
import { Button, Form, Image, Spinner } from "react-bootstrap"
import { useDispatch, useSelector } from "react-redux"
import { useNavigate } from "react-router-dom"

import Loading from "~/components/Loading"
import { authSelector, tasksSelector } from "~/redux/selectors"
import { addDiscussion, getTaskDiscussion } from "~/redux/tasksSlice"

const TaskDiscussion = ({ taskId }) => {
    const userInfo = useSelector(authSelector).userInfo

    const status = useSelector(tasksSelector).status
    const discussions = useSelector(tasksSelector).discussions

    const dispatch = useDispatch()
    const navigate = useNavigate()

    const [content, setContent] = useState("")

    useEffect(() => {
        dispatch(getTaskDiscussion(taskId))
    }, [])

    const handleAddDiscussion = () => {
        dispatch(addDiscussion({ taskId: taskId, content }))
        setContent("")
    }

    return (
        <>
            <div className="taskDiscussion__wrapper">
                {status === "loadingDiscussion" ? (
                    <Loading />
                ) : discussions.length === 0 ? (
                    <div className="text-center">Chưa có thảo luận</div>
                ) : (
                    discussions.map((discussion, index) => (
                        <div key={index} className={discussion.modifyById === userInfo.id ? "taskDiscussion__item reverse" : "taskDiscussion__item"}>
                            <Image
                                src={"data:image/png;base64," + discussion.avatar}
                                className="taskDiscussion__avatar"
                                onClick={() => navigate(`/profile/${discussion.modifyById}`)}
                            />
                            <div className="taskDiscussion__detail">
                                <div
                                    className={discussion.modifyById === userInfo.id ? "taskDiscussion__detail__info reverse" : "taskDiscussion__detail__info"}
                                >
                                    <div className="taskDiscussion__detail__info--name" onClick={() => navigate(`/profile/${discussion.modifyById}`)}>
                                        {discussion.modifyById === userInfo.id ? "Bạn" : discussion.modifyBy}
                                    </div>
                                    <div className="taskDiscussion__detail__info--time">{discussion.modifyDate}</div>
                                </div>
                                <div className="taskDiscussion__detail__content">{discussion.content}</div>
                            </div>
                        </div>
                    ))
                )}
            </div>
            <hr />
            <div className="d-flex justify-content-evenly">
                <div className="col-auto">
                    <Image className="rounded-circle me-2" src={"data:image/png;base64," + userInfo.avatar} width={50} height={50} />
                    
                </div>
                <div className="col">
                    <Form.Control
                        as="textarea"
                        name="content"
                        placeholder="Nhập nội dung thảo luận"
                        rows={3}
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                    />
                </div>
            </div>
            <div className="d-flex justify-content-end mt-2">
                <Button disabled={content === "" || status === "sending"} onClick={handleAddDiscussion}>
                    Gửi
                    {status === "sending" && <Spinner as="span" animation="border" size="sm" className="ms-2" />}
                </Button>
            </div>
        </>
    )
}

export default TaskDiscussion
