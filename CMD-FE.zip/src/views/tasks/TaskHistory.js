import React from "react"
import PropTypes from "prop-types"
import { Col, Image, Row } from "react-bootstrap"
import { useNavigate } from "react-router-dom"
import { useSelector } from "react-redux"

import { authSelector } from "~/redux/selectors"

const propTypes = {
    taskInfo: PropTypes.object.isRequired,
}

const TaskHistory = ({ taskInfo }) => {
    const userInfo = useSelector(authSelector).userInfo

    const navigate = useNavigate()

    return (
        <div className="taskHistory__wrapper">
            {taskInfo.taskHis?.length === 0 ? (
                <div className="text-center">Chưa có lịch sử</div>
            ) : (
                taskInfo.taskHis?.map((history, index) => (
                    <div className={history.modifyById === userInfo.id ? "taskHistory__item reverse" : "taskHistory__item"} key={index}>
                    <Image
                        src={"data:image/png;base64," + history.avatar}
                        className="taskHistory__avatar"
                        onClick={() => navigate(`/profile/${history.modifyById}`)}
                    />
                        <div className="taskHistory__detail">
                            <div
                                className={history.modifyById === userInfo.id ? "taskHistory__detail__info reverse" : "taskHistory__detail__info"}
                            >
                                <div className="taskHistory__detail__info--name" onClick={() => navigate(`/profile/${history.modifyById}`)}>
                                    {history.modifyById === userInfo.id ? "Bạn" : history.modifyBy}
                                </div>
                                <div className="taskHistory__detail__info--time">{history.modifyDate}</div>
                            </div>
                            <div className="taskHistory__detail__message">{history.message}</div>
                        </div>
                    </div>
                ))
            )}
        </div>
    )
}

TaskHistory.propTypes = propTypes

export default TaskHistory
